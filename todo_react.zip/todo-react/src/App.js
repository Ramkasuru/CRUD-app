import "./App.css";
import { TodoWrapper } from "./Components/TodoWrapper";

function App() {
  return (
    <div className="App">
      <TodoWrapper />
    </div>
  );
}

export default App;